
<footer id="footer">
    <div class="container">
        <div class="copyright">
          INTERWORLD SHIPPING OVERSEAS LIMITED (ISOL)  &copy; Copyright. All Rights Reserved
        </div>
    </div>
</footer><!-- End Footer -->
